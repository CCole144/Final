// scripts.js
function validateForm(event) {
  event.preventDefault();

  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const phone = document.getElementById('phone').value;
  const email = document.getElementById('email').value;

  const phonePattern = /^\d{10}$/;
  const emailPattern = /^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/;

  if (!firstName || !lastName || !phone || !email) {
    alert('All fields are required.');
    return;
  }
  if (!phonePattern.test(phone)) {
    alert('Phone number must be 10 digits.');
    return;
  }
  if (!emailPattern.test(email)) {
    alert('Invalid email address.');
    return;
  }

  alert(`Summary:\\nFirst Name: ${firstName}\\nLast Name: ${lastName}\\nPhone: ${phone}\\nEmail: ${email}`);
}

function resetForm() {
  document.getElementById('contact-form').reset();
}

document.addEventListener('DOMContentLoaded', () => {
  const sendBtn = document.getElementById('sendBtn');
  const resetBtn = document.getElementById('resetBtn');

  if (sendBtn && resetBtn) {
    sendBtn.addEventListener('click', validateForm);
    resetBtn.addEventListener('click', resetForm);
  }
});
